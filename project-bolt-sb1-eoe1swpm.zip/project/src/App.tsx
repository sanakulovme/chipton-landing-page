import React, { useState } from 'react';
import VerifyProfileTemplate from './components/EmailTemplates/VerifyProfileTemplate';
import TwoStepVerificationTemplate from './components/EmailTemplates/TwoStepVerificationTemplate';

function App() {
  const [activeTemplate, setActiveTemplate] = useState<'profile' | 'twoStep'>('profile');

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Template Selector */}
      <div className="max-w-7xl mx-auto py-6 px-4">
        <div className="bg-white rounded-lg shadow-sm p-4 mb-6 flex justify-center gap-4">
          <button
            onClick={() => setActiveTemplate('profile')}
            className={`px-4 py-2 rounded-md transition-colors ${
              activeTemplate === 'profile'
                ? 'bg-indigo-600 text-white'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            Profile Verification
          </button>
          <button
            onClick={() => setActiveTemplate('twoStep')}
            className={`px-4 py-2 rounded-md transition-colors ${
              activeTemplate === 'twoStep'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            Two-Step Verification
          </button>
        </div>
      </div>

      {/* Template Display */}
      {activeTemplate === 'profile' ? (
        <VerifyProfileTemplate
          username="John Doe"
          verificationLink="https://example.com/verify?token=abc123xyz456"
          companyName="SecureApp"
        />
      ) : (
        <TwoStepVerificationTemplate
          username="John Doe"
          verificationCode="123456"
          expiryMinutes={15}
          companyName="SecureApp"
        />
      )}
    </div>
  );
}

export default App;