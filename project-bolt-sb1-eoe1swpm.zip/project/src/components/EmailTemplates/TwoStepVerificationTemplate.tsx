import React from 'react';
import { LockKeyhole, Clock, Shield } from 'lucide-react';

interface TwoStepVerificationTemplateProps {
  username: string;
  verificationCode: string;
  expiryMinutes?: number;
  companyName?: string;
  companyLogo?: string;
}

const TwoStepVerificationTemplate: React.FC<TwoStepVerificationTemplateProps> = ({
  username,
  verificationCode,
  expiryMinutes = 10,
  companyName = 'YourCompany',
  companyLogo,
}) => {
  return (
    <div className="bg-gray-100 font-sans min-h-screen p-6">
      <div className="max-w-md mx-auto bg-white rounded-xl shadow-md overflow-hidden">
        {/* Header */}
        <div className="bg-blue-600 p-6 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              {companyLogo ? (
                <img src={companyLogo} alt={companyName} className="h-8 w-auto" />
              ) : (
                <Shield className="h-8 w-8" />
              )}
              <span className="text-xl font-bold">{companyName}</span>
            </div>
            <LockKeyhole className="h-6 w-6" />
          </div>
        </div>
        
        {/* Content */}
        <div className="p-6">
          <h1 className="text-2xl font-bold text-gray-800 mb-4">Two-Step Verification Code</h1>
          
          <p className="text-gray-600 mb-6">
            Hi {username},
          </p>
          
          <p className="text-gray-600 mb-6">
            We received a request to access your account. Enter the following verification 
            code to complete the sign-in process:
          </p>
          
          <div className="mb-8">
            <div className="bg-gray-100 rounded-lg p-4 text-center">
              <div className="font-mono text-3xl font-bold tracking-widest text-gray-800">
                {verificationCode.split('').join(' ')}
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2 text-sm text-gray-500 mb-6">
            <Clock className="h-4 w-4" />
            <span>This code will expire in {expiryMinutes} minutes</span>
          </div>
          
          <div className="border-t border-gray-200 pt-6 text-sm text-gray-500">
            <p>
              If you didn't request this code, please ignore this message or contact 
              support if you're concerned about your account's security.
            </p>
          </div>
        </div>
        
        {/* Footer */}
        <div className="bg-gray-50 p-6 border-t border-gray-200">
          <p className="text-sm text-gray-500 mb-2">
            This is an automated message, please do not reply.
          </p>
          <p className="text-sm text-gray-500">
            &copy; {new Date().getFullYear()} {companyName}. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  );
};

export default TwoStepVerificationTemplate;