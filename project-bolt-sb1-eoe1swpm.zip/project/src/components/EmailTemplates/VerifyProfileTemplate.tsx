import React from 'react';
import { Mail, Shield, ArrowRight } from 'lucide-react';

interface VerifyProfileTemplateProps {
  username: string;
  verificationLink: string;
  companyName?: string;
  companyLogo?: string;
}

const VerifyProfileTemplate: React.FC<VerifyProfileTemplateProps> = ({
  username,
  verificationLink,
  companyName = 'YourCompany',
  companyLogo,
}) => {
  return (
    <div className="bg-gray-100 font-sans min-h-screen p-6">
      <div className="max-w-md mx-auto bg-white rounded-xl shadow-md overflow-hidden">
        {/* Header */}
        <div className="bg-indigo-600 p-6 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              {companyLogo ? (
                <img src={companyLogo} alt={companyName} className="h-8 w-auto" />
              ) : (
                <Shield className="h-8 w-8" />
              )}
              <span className="text-xl font-bold">{companyName}</span>
            </div>
            <Mail className="h-6 w-6" />
          </div>
        </div>
        
        {/* Content */}
        <div className="p-6">
          <h1 className="text-2xl font-bold text-gray-800 mb-4">Verify Your Profile</h1>
          
          <p className="text-gray-600 mb-6">
            Hi {username},
          </p>
          
          <p className="text-gray-600 mb-6">
            Thank you for signing up! To complete your registration and access all features, 
            please verify your profile by clicking the button below.
          </p>
          
          <div className="mb-6">
            <a 
              href={verificationLink}
              className="inline-block bg-indigo-600 text-white font-bold py-3 px-6 rounded-lg transition-all duration-300 hover:bg-indigo-700 hover:transform hover:-translate-y-0.5 hover:shadow-lg"
            >
              <div className="flex items-center justify-center space-x-2">
                <span>Verify My Profile</span>
                <ArrowRight className="h-4 w-4" />
              </div>
            </a>
          </div>
          
          <div className="border-t border-gray-200 pt-6 text-sm text-gray-500">
            <p className="mb-2">
              If the button doesn't work, copy and paste this link into your browser:
            </p>
            <a 
              href={verificationLink}
              className="text-indigo-600 break-all hover:underline"
            >
              {verificationLink}
            </a>
          </div>
        </div>
        
        {/* Footer */}
        <div className="bg-gray-50 p-6 border-t border-gray-200">
          <p className="text-sm text-gray-500 mb-2">
            If you didn't create an account, you can safely ignore this email.
          </p>
          <p className="text-sm text-gray-500">
            &copy; {new Date().getFullYear()} {companyName}. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  );
};

export default VerifyProfileTemplate;